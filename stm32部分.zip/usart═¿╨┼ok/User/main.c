#include "stm32f10x.h"
#include "bsp_led.h"
#include "delay.h"
#include "bsp_usart_wxw.h"
#include "bsp_usart_zyh.h"
#include "bsp_usart_data.h"
#include "stdio.h"
#include "string.h"
#include "stdlib.h"
#include "bsp_GeneralTim.h" 
#include "bsp_uart_lw.h"
#include "bsp_uart_yj.h"
extern char receivebuff_wxw[100];
extern char *data_wxw;
extern char receivebuff_zyh[100];
extern char *data_zyh;
extern char receivebuff_data[100];
extern char *data_data;
extern uint8_t SendBuff_WXW[SENDBUFF_SIZE_WXW];
extern char receivebuff_lw[100];
extern char *data_lw;
extern char receivebuff_yj[100];
extern char *data_yj;
char display_data[100]={0};
u8 flag_csb_person=0;

int x;
float t;
int wxw;
char tem_str[10]={0};
uint16_t get_hex;
uint16_t get_hex_csb;
u8 sum=0,i=0;
uint16_t distance=0;
void test_usart(void);
/**
  * @brief  ������
  * @param  ��  
  * @retval ��
  */
int main(void)
{
	
	LED_GPIO_Config();	 
	usart_wxw_init();//����
	usart_zyh_init();//�û�1
	usart_data_init();//�û�2
	usart_lw_init();//�¶�
	usart_yj_init();//������
	GENERAL_TIM_Init(1999,719);//arr,psc
	printf("wxw\n");
	while (1)
	{
		test_usart();
	}
}
void test_usart(void)
{
	if(data_wxw)
	{
		//����
		//printf("www\n");
//		Get_Number('s','p',data_wxw,&x);
//		TIM_SetCompare1(TIM3,x);
//		Usart_SendString(UART4,"0");
		//Usart_SendString(UART4,"1");//���
		//Usart_SendString(UART4,"2");//�̵�
		data_wxw=NULL;
	}
	if(data_zyh)
	{
		data_zyh=NULL;
	}
	if(data_data)
	{
		if(strcmp(data_data,"opendoor")==0)
		{
			TIM_SetCompare1(TIM3,1750);//����
			delay_ms(20);
		}
		else if(strcmp(data_data,"closedoor")==0)
		{
			TIM_SetCompare1(TIM3,1850);//����
			delay_ms(20);
		}
		printf("%s\n",data_data);
		data_data=NULL;
	}
	if(data_lw)
	{
		get_hex=data_lw[2];
		get_hex = get_hex << 8;
		get_hex = get_hex | data_lw[3];
		wxw=get_hex;
		t = (wxw*1.0) / 16.0 - 273.15;
		if(flag_csb_person==1)
		{
			if(t>=32.00)
			{
				Usart_SendString(UART4,"1");//���
				Usart_SendString(USART3,"page1.t6.txt=\"�쳣\"\xff\xff\xff");
			}
			else
			{
				Usart_SendString(UART4,"2");//�̵�
				Usart_SendString(USART3,"page1.t6.txt=\"����\"\xff\xff\xff");
			}
			zero_str(tem_str,10);
			zero_str(display_data,100);
			//printf("%.2f\n",t);
			sprintf(tem_str,"%.2f",t);
			Usart_SendString(USART2,tem_str);
			sprintf(display_data,"page1.t1.txt=\"%.2f\"\xff\xff\xff",t);
			Usart_SendString(USART3,display_data);
		}
		
		//printf("%s\n",data_lw);
		data_lw=NULL;
	}
	if(data_yj)
	{
		get_hex_csb=data_yj[5];
		get_hex_csb = get_hex_csb << 8;
		get_hex_csb = get_hex_csb | data_yj[6];
		if(get_hex_csb>25)
		{
			flag_csb_person=0;
			Usart_SendString(UART4,"0");//�̵�
			Usart_SendString(USART3,"page1.t3.txt=\"��\"\xff\xff\xff");
		}
		else
		{
			flag_csb_person=1;
			Usart_SendString(USART3,"page1.t3.txt=\"��\"\xff\xff\xff");
		}
		printf("%d\n",get_hex_csb);
//		printf("%s\n",data_yj);
		data_yj=NULL;
	}
}
/*********************************************END OF FILE**********************/
