#include "delay.h"


/*
us:
��=1us,i=6
��<10us,i=7
��<100us,i=8
��>100us&<1000us,ֵ+4
*/
void delay_us(uint16_t x)//1us
{
	uint16_t i;
	for(;x>0;x--)
		for(i=0;i<8;i++);
}

void delay_ms(uint16_t x)//1ms
{
	uint16_t i;
	for(;x>0;x--)
		for(i=0;i<8002;i++);
}

