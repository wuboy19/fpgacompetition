#ifndef _BSP_USART_DATA_H_
#define _BSP_USART_DATA_H_
#include "stm32f10x.h"

#include <stdio.h>
#define  USART_DATA                    USART3
#define  USART_DATA_CLK                RCC_APB1Periph_USART3
#define  USART_DATA_APBxClkCmd         RCC_APB1PeriphClockCmd
#define  USART_DATA_BAUDRATE           115200

// USART GPIO ���ź궨��
#define  USART_DATA_GPIO_CLK           (RCC_APB2Periph_GPIOB)
#define  USART_DATA_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  USART_DATA_TX_GPIO_PORT       GPIOB   
#define  USART_DATA_TX_GPIO_PIN        GPIO_Pin_10
#define  USART_DATA_RX_GPIO_PORT       GPIOB
#define  USART_DATA_RX_GPIO_PIN        GPIO_Pin_11

#define  USART_DATA_USART_IRQ                USART3_IRQn
#define  USART_DATA_USART_IRQHandler         USART3_IRQHandler
// ���ڶ�Ӧ��DMA����ͨ��
#define  USART_TX_DMA_DATA_CHANNEL               DMA1_Channel2
#define  USART_TX_DMA_DATA_DMA_IRQ                DMA1_Channel2_IRQn
#define  USART_TX_DMA_DATA_DMA_IRQHandler         DMA1_Channel2_IRQHandler
#define  USART_TX_DMA_DATA_DMA_FLAG_TC            DMA1_FLAG_TC2
// ����Ĵ�����ַ
#define  USART_DR_ADDRESS_DATA        (&USART_DATA->DR)
// һ�η��͵�������
#define  SENDBUFF_SIZE_DATA            100

void USARTx_DMA_DATA_Config(void);
static void NVIC_DMA_TX_DATA_Configuration(void);
void DMA_TX_DATA(uint8_t *tx_buffer,uint16_t length);
void usart_data_init(void);
#endif /* _BSP_USART_DATA_H_*/


