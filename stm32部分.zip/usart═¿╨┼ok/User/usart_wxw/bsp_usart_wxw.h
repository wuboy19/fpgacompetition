#ifndef _BSP_USART_WXW_H_
#define _BSP_USART_WXW_H_
#include "stm32f10x.h"
#include <stdio.h>
#define  USART_WXW                    USART1
#define  USART_WXW_CLK                RCC_APB2Periph_USART1
#define  USART_WXW_APBxClkCmd         RCC_APB2PeriphClockCmd
#define  USART_WXW_BAUDRATE           115200




// USART GPIO ���ź궨��
#define  USART_WXW_GPIO_CLK           (RCC_APB2Periph_GPIOA)
#define  USART_WXW_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  USART_WXW_TX_GPIO_PORT       GPIOA   
#define  USART_WXW_TX_GPIO_PIN        GPIO_Pin_9
#define  USART_WXW_RX_GPIO_PORT       GPIOA
#define  USART_WXW_RX_GPIO_PIN        GPIO_Pin_10

//USART��ӳ��
#define  USART_WXW_CLK_Remap          RCC_APB2Periph_AFIO
#define  USART_WXW_APBxClkCmd_Remap   RCC_APB2PeriphClockCmd
#define  USART_WXW_START_Remap        GPIO_Remap_USART1
// USART GPIO ��ӳ�����ź궨��
#define  USART_WXW_GPIO_CLK_Remap       (RCC_APB2Periph_GPIOB)
#define  USART_WXW_GPIO_APBxClkCmd_Remap RCC_APB2PeriphClockCmd
    
#define  USART_WXW_TX_GPIO_PORT_Remap       GPIOB   
#define  USART_WXW_TX_GPIO_PIN_Remap        GPIO_Pin_6
#define  USART_WXW_RX_GPIO_PORT_Remap       GPIOB
#define  USART_WXW_RX_GPIO_PIN_Remap        GPIO_Pin_7

#define  USART_WXW_USART_IRQ                USART1_IRQn
#define  USART_WXW_USART_IRQHandler         USART1_IRQHandler

// ���ڶ�Ӧ��DMA����ͨ��
#define  USART_TX_DMA_WXW_CHANNEL     DMA1_Channel4

#define  USART_TX_DMA_WXW_DMA_IRQ                DMA1_Channel4_IRQn
#define  USART_TX_DMA_WXW_DMA_IRQHandler         DMA1_Channel4_IRQHandler
#define  USART_TX_DMA_WXW_DMA_FLAG_TC            DMA1_FLAG_TC4
// ����Ĵ�����ַ
#define  USART_DR_ADDRESS_WXW        (&USART_WXW->DR)
// һ�η��͵�������
#define  SENDBUFF_SIZE_WXW            100
void usart_wxw_init(void);
void USARTx_DMA_WXW_Config(void);
void DMA_TX_WXW(uint8_t *tx_buffer,uint16_t length);
static void NVIC_DMA_TX_WXW_Configuration(void);
static void NVIC_DMA_RX_Configuration(void);
void Usart_SendByte( USART_TypeDef * pUSARTx, uint8_t ch);
void Usart_SendString( USART_TypeDef * pUSARTx, char *str);
void Usart_SendHalfWord( USART_TypeDef * pUSARTx, uint16_t ch);
void zero_str(char *str,u8 index);
void usart_wxw_Remap_init(void);
void Get_Number(char x,char y,char *source,int *result);//eg:223112a200b�õ�200�������
#endif /* _BSP_USART_WXW_H_*/


