#ifndef _BSP_UART_LW_H
#define _BSP_UART_LW_H


#include "stm32f10x.h"
#include <stdio.h>
#define  USART_LW                    UART4
#define  USART_LW_CLK                RCC_APB1Periph_UART4
#define  USART_LW_APBxClkCmd         RCC_APB1PeriphClockCmd
#define  USART_LW_BAUDRATE           19200

// USART GPIO ���ź궨��
#define  USART_LW_GPIO_CLK           (RCC_APB2Periph_GPIOC)
#define  USART_LW_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  USART_LW_TX_GPIO_PORT       GPIOC   
#define  USART_LW_TX_GPIO_PIN        GPIO_Pin_10
#define  USART_LW_RX_GPIO_PORT       GPIOC
#define  USART_LW_RX_GPIO_PIN        GPIO_Pin_11

#define  USART_LW_USART_IRQ                UART4_IRQn
#define  USART_LW_USART_IRQHandler         UART4_IRQHandler

void usart_lw_init(void);

#endif	/* _BSP_UART_LW_H */


