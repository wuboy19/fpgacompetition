#ifndef _BSP_UART_YJ_H
#define _BSP_UART_YJ_H


#include "stm32f10x.h"
#include <stdio.h>
#define  USART_YJ                    UART5
#define  USART_YJ_CLK                RCC_APB1Periph_UART5
#define  USART_YJ_APBxClkCmd         RCC_APB1PeriphClockCmd
#define  USART_YJ_BAUDRATE           9600

// USART GPIO ���ź궨��
#define  USART_YJ_GPIO_CLK           (RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOD)
#define  USART_YJ_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  USART_YJ_TX_GPIO_PORT       GPIOC   
#define  USART_YJ_TX_GPIO_PIN        GPIO_Pin_12
#define  USART_YJ_RX_GPIO_PORT       GPIOD
#define  USART_YJ_RX_GPIO_PIN        GPIO_Pin_2

#define  USART_YJ_USART_IRQ                UART5_IRQn
#define  USART_YJ_USART_IRQHandler         UART5_IRQHandler

void usart_yj_init(void);

#endif	/* _BSP_UART_YJ_H */