#ifndef _BSP_USART_ZYH_H_
#define _BSP_USART_ZYH_H_
#include "stm32f10x.h"
#include <stdio.h>
#define  USART_ZYH                    USART2
#define  USART_ZYH_CLK                RCC_APB1Periph_USART2
#define  USART_ZYH_APBxClkCmd         RCC_APB1PeriphClockCmd
#define  USART_ZYH_BAUDRATE           115200

// USART GPIO ���ź궨��
#define  USART_ZYH_GPIO_CLK           (RCC_APB2Periph_GPIOA)
#define  USART_ZYH_GPIO_APBxClkCmd    RCC_APB2PeriphClockCmd
    
#define  USART_ZYH_TX_GPIO_PORT       GPIOA   
#define  USART_ZYH_TX_GPIO_PIN        GPIO_Pin_2
#define  USART_ZYH_RX_GPIO_PORT       GPIOA
#define  USART_ZYH_RX_GPIO_PIN        GPIO_Pin_3

#define  USART_ZYH_USART_IRQ                USART2_IRQn
#define  USART_ZYH_USART_IRQHandler         USART2_IRQHandler


// ���ڶ�Ӧ��DMA����ͨ��
#define  USART_TX_DMA_ZYH_CHANNEL     DMA1_Channel7

#define  USART_TX_DMA_ZYH_DMA_IRQ                DMA1_Channel7_IRQn
#define  USART_TX_DMA_ZYH_DMA_IRQHandler         DMA1_Channel7_IRQHandler
#define  USART_TX_DMA_ZYH_DMA_FLAG_TC            DMA1_FLAG_TC7
// ����Ĵ�����ַ
#define  USART_DR_ADDRESS_ZYH        (&USART_ZYH->DR)
// һ�η��͵�������
#define  SENDBUFF_SIZE_ZYH            100

void usart_zyh_init(void);
void USARTx_DMA_ZYH_Config(void);
static void NVIC_DMA_TX_ZYH_Configuration(void);
void DMA_TX_ZYH(uint8_t *tx_buffer,uint16_t length);
#endif /* _BSP_USART_ZYH_H_*/


